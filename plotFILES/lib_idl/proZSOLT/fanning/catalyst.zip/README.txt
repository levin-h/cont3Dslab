The Catalyst Library is an Open Source programming project, hosted at
http://catalyst.idldev.com. 

AUTHORS:

  David W. Fanning              David Burridge
  FANNING SOFTWARE CONSULTING   BURRIDGE COMPUTING
  1645 Sheely Drive             18 The Green South
  Fort Collins                  Warborough, Oxon
  CO 80526 USA                  OX10 7DN, ENGLAND
  Phone: 970-221-0438           Phone: +44 (0)1865 858279
  E-mail: davidf@dfanning.com   E-mail: davidb@burridgecomputing.co.uk

If you have a question about the software or how to use
it, please contact Davd Fanning via e-mail. We try
very hard to answer questions in a timely manner, although
both of us are working full-time at jobs other than this one.
